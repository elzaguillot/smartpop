
./smartpop -p 100 --polygamy 3 -t 10000 --sample 50 --header -o example1
./smartpop -p 500 --polygamy 3 -t 10000 --sample 50 -o example1
./smartpop -p 1000 --polygamy 3 -t 10000 --sample 50 -o example1
./smartpop -p 5000 --polygamy 3 -t 10000 --sample 50 -o example1
./smartpop -p 10000 --polygamy 3 -t 10000 --sample 50 -o example1
