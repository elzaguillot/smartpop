./smartpop -p 200 --nsimu 1000 --polygamy 1 --sample 20  -t 5 --nstep 50 -o example2_mono --header --inbreeding 1 
./smartpop -p 200 --nsimu 1000 --polygamy 5 --sample 20  -t 5 --nstep 50 -o example2_poly --header --inbreeding 1 
